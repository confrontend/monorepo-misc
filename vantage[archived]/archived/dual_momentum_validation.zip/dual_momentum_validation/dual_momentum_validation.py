#!/usr/bin/env python3
"""Reproducible validation of two pre-registered dual-momentum strategies.

Strategies
----------
DM-Cash:
    Risky assets SPY/EFA; BIL is both the absolute-momentum hurdle and fallback.
DM-Bond:
    Risky assets SPY/EFA; BIL is the hurdle and AGG is the fallback.

Signal and execution
--------------------
At each actual month-end trading close:
1. Compute 12-month total returns of SPY, EFA, and BIL from adjusted closes.
2. Select the stronger equity ETF.
3. Hold it if its return exceeds BIL's return; otherwise hold the fallback.
4. Execute at the next trading session's adjusted open.
5. Hold from that adjusted open to the following month's adjusted open.

The script deliberately does not optimize the lookback or assets. It exports the
complete signal, execution, return, cost, metric, rolling-return, bootstrap, and
validation ledgers needed to audit the result.

Usage
-----
    python dual_momentum_validation.py --output-dir dm_results

Optional cached/local data:
    python dual_momentum_validation.py --data-dir ./price_csvs --output-dir dm_results

CSV files in --data-dir should be named SPY.csv, EFA.csv, BIL.csv, and AGG.csv.
Accepted columns: Date, Open, Close, Adj Close, Dividends, Stock Splits.
If files are absent, the script downloads and caches data using yfinance.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import yfinance as yf
except ImportError as exc:  # pragma: no cover - explicit user-facing failure
    raise SystemExit(
        "Missing dependency 'yfinance'. Install requirements with:\n"
        "  python -m pip install -r requirements_dual_momentum.txt"
    ) from exc


TICKERS: Tuple[str, ...] = ("SPY", "EFA", "BIL", "AGG")
DOWNLOAD_START = "2006-12-01"
# yfinance's end date is exclusive. This captures the first 2026 execution needed
# to close the December 2025 holding interval.
DOWNLOAD_END = "2026-02-15"
REQUESTED_TEST_START = pd.Timestamp("2008-01-01")
DEVELOPMENT_END = pd.Timestamp("2015-12-31")
HOLDOUT_START = pd.Timestamp("2016-01-01")
HOLDOUT_END = pd.Timestamp("2025-12-31")
BOOTSTRAP_SEED = 20260731
BOOTSTRAP_SAMPLES = 10_000
BOOTSTRAP_BLOCK_MONTHS = 12


@dataclass(frozen=True)
class StrategyDefinition:
    name: str
    fallback: str


STRATEGIES: Tuple[StrategyDefinition, ...] = (
    StrategyDefinition("DM-Cash", "BIL"),
    StrategyDefinition("DM-Bond", "AGG"),
)


@dataclass
class PerformanceMetrics:
    observations: int
    years: float
    cumulative_return: float
    cagr: float
    annualized_volatility: float
    sharpe_vs_bil: float
    sortino_vs_bil: float
    max_drawdown: float
    worst_calendar_year: int | None
    worst_calendar_return: float
    annual_gross_traded_notional: float
    switches_per_year: float


class ValidationError(RuntimeError):
    """Raised when data or alignment checks invalidate the test."""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the pre-registered dual-momentum validation."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("dual_momentum_results"),
        help="Directory for CSV/JSON outputs (default: dual_momentum_results).",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=None,
        help=(
            "Optional directory containing/caching SPY.csv, EFA.csv, BIL.csv, "
            "and AGG.csv. Missing files are downloaded."
        ),
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Ignore cached CSVs and download all price data again.",
    )
    parser.add_argument(
        "--bootstrap-samples",
        type=int,
        default=BOOTSTRAP_SAMPLES,
        help=f"Moving-block bootstrap samples (default: {BOOTSTRAP_SAMPLES}).",
    )
    return parser.parse_args()


def normalize_index(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    if "Date" in frame.columns:
        frame["Date"] = pd.to_datetime(frame["Date"], errors="coerce")
        frame = frame.set_index("Date")
    frame.index = pd.to_datetime(frame.index, errors="coerce")
    if getattr(frame.index, "tz", None) is not None:
        frame.index = frame.index.tz_localize(None)
    frame = frame[~frame.index.isna()].sort_index()
    frame = frame[~frame.index.duplicated(keep="last")]
    return frame


def flatten_single_ticker_columns(frame: pd.DataFrame, ticker: str) -> pd.DataFrame:
    """Normalize yfinance output across old/new column layouts."""
    frame = frame.copy()
    if isinstance(frame.columns, pd.MultiIndex):
        # yfinance may return (Price, Ticker) or (Ticker, Price).
        levels = [set(map(str, frame.columns.get_level_values(i))) for i in range(frame.columns.nlevels)]
        ticker_level = next((i for i, values in enumerate(levels) if ticker in values), None)
        if ticker_level is not None:
            frame = frame.xs(ticker, axis=1, level=ticker_level, drop_level=True)
        else:
            frame.columns = ["_".join(map(str, col)).strip("_") for col in frame.columns]
    return frame


def download_ticker(ticker: str) -> pd.DataFrame:
    frame = yf.download(
        ticker,
        start=DOWNLOAD_START,
        end=DOWNLOAD_END,
        interval="1d",
        auto_adjust=False,
        actions=True,
        repair=True,
        progress=False,
        threads=False,
        group_by="column",
        multi_level_index=False,
    )
    if frame is None or frame.empty:
        raise ValidationError(f"No data downloaded for {ticker}.")
    return normalize_index(flatten_single_ticker_columns(frame, ticker))


def load_ticker_csv(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    return normalize_index(frame)


def standardize_ticker_frame(frame: pd.DataFrame, ticker: str) -> pd.DataFrame:
    aliases = {str(col).strip().lower().replace("_", " "): col for col in frame.columns}

    def get_col(names: Iterable[str], required: bool = True) -> Optional[pd.Series]:
        for name in names:
            key = name.lower().replace("_", " ")
            if key in aliases:
                return pd.to_numeric(frame[aliases[key]], errors="coerce")
        if required:
            raise ValidationError(
                f"{ticker}: missing one of required columns {list(names)}; "
                f"found {list(frame.columns)}"
            )
        return None

    raw_open = get_col(["Open"])
    raw_close = get_col(["Close"])
    adj_close = get_col(["Adj Close", "Adjusted Close"])
    dividends = get_col(["Dividends"], required=False)
    splits = get_col(["Stock Splits", "Splits"], required=False)

    if adj_close is None:
        raise ValidationError(f"{ticker}: adjusted close is required.")

    adjustment_factor = adj_close / raw_close.replace(0.0, np.nan)
    adjusted_open = raw_open * adjustment_factor

    standardized = pd.DataFrame(
        {
            "ticker": ticker,
            "open": raw_open,
            "close": raw_close,
            "adj_close": adj_close,
            "adj_open": adjusted_open,
            "dividends": dividends if dividends is not None else 0.0,
            "stock_splits": splits if splits is not None else 0.0,
        },
        index=frame.index,
    )
    standardized.index.name = "date"
    standardized = standardized.replace([np.inf, -np.inf], np.nan)
    standardized = standardized.dropna(subset=["open", "close", "adj_close", "adj_open"])

    if standardized.empty:
        raise ValidationError(f"{ticker}: no usable rows after standardization.")
    if (standardized[["open", "close", "adj_close", "adj_open"]] <= 0).any().any():
        raise ValidationError(f"{ticker}: non-positive price found.")
    return standardized


def load_all_prices(
    data_dir: Optional[Path], refresh: bool
) -> Tuple[Dict[str, pd.DataFrame], Dict[str, str]]:
    if data_dir is not None:
        data_dir.mkdir(parents=True, exist_ok=True)

    prices: Dict[str, pd.DataFrame] = {}
    sources: Dict[str, str] = {}
    for ticker in TICKERS:
        csv_path = data_dir / f"{ticker}.csv" if data_dir else None
        if csv_path and csv_path.exists() and not refresh:
            raw = load_ticker_csv(csv_path)
            sources[ticker] = f"cache:{csv_path.resolve()}"
        else:
            raw = download_ticker(ticker)
            sources[ticker] = "yfinance"
            if csv_path:
                export = raw.copy()
                export.index.name = "Date"
                export.reset_index().to_csv(csv_path, index=False)
        prices[ticker] = standardize_ticker_frame(raw, ticker)
    return prices, sources


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_price_panels(
    prices: Mapping[str, pd.DataFrame]
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    adj_close = pd.concat(
        {ticker: frame["adj_close"] for ticker, frame in prices.items()}, axis=1
    ).sort_index()
    adj_open = pd.concat(
        {ticker: frame["adj_open"] for ticker, frame in prices.items()}, axis=1
    ).sort_index()
    raw_long = pd.concat(prices.values(), axis=0).sort_index()
    return adj_close, adj_open, raw_long


def actual_month_end_rows(panel: pd.DataFrame) -> pd.DataFrame:
    """Return rows on actual final trading dates, not synthetic calendar dates."""
    result = panel.groupby(panel.index.to_period("M"), sort=True).tail(1)
    if result.index.to_period("M").duplicated().any():
        raise ValidationError("Month-end extraction produced duplicate periods.")
    return result


def next_common_session(after: pd.Timestamp, panel: pd.DataFrame) -> pd.Timestamp:
    candidates = panel.index[(panel.index > after) & panel.notna().all(axis=1)]
    if candidates.empty:
        raise ValidationError(f"No common next session after {after.date()}.")
    return pd.Timestamp(candidates[0])


def generate_signals(
    adj_close: pd.DataFrame, adj_open: pd.DataFrame
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    monthly_close = actual_month_end_rows(adj_close)
    momentum_12m = monthly_close.pct_change(12, fill_method=None)
    spy_sma_10m = monthly_close["SPY"].rolling(10, min_periods=10).mean()

    rows = []
    for signal_date in monthly_close.index:
        # The historical validation is locked through December 2025. Later or
        # partial months must not leak into the test or create synthetic month-ends.
        if signal_date > HOLDOUT_END:
            continue
        mom = momentum_12m.loc[signal_date]
        if mom[["SPY", "EFA", "BIL"]].isna().any():
            continue
        if signal_date < REQUESTED_TEST_START:
            continue

        equity_winner = "SPY" if mom["SPY"] >= mom["EFA"] else "EFA"
        winner_return = float(mom[equity_winner])
        bil_return = float(mom["BIL"])
        risk_on = winner_return > bil_return

        execution_date = next_common_session(signal_date, adj_open)
        if execution_date > pd.Timestamp(DOWNLOAD_END):
            continue

        sma_value = spy_sma_10m.loc[signal_date]
        if pd.isna(sma_value):
            continue

        rows.append(
            {
                "signal_date": signal_date,
                "execution_date": execution_date,
                "spy_12m": float(mom["SPY"]),
                "efa_12m": float(mom["EFA"]),
                "bil_12m": bil_return,
                "equity_winner": equity_winner,
                "winner_12m": winner_return,
                "risk_on": bool(risk_on),
                "DM-Cash": equity_winner if risk_on else "BIL",
                "DM-Bond": equity_winner if risk_on else "AGG",
                "SPY-Absolute": "SPY" if float(mom["SPY"]) > bil_return else "BIL",
                "SPY-10M-SMA": "SPY"
                if float(monthly_close.loc[signal_date, "SPY"]) > float(sma_value)
                else "BIL",
            }
        )

    signals = pd.DataFrame(rows)
    if signals.empty:
        raise ValidationError("No valid signals were generated.")
    signals = signals.sort_values("signal_date").reset_index(drop=True)

    notes: Dict[str, str] = {}
    first_signal = pd.Timestamp(signals.loc[0, "signal_date"])
    first_execution = pd.Timestamp(signals.loc[0, "execution_date"])
    if first_signal.to_period("M") > REQUESTED_TEST_START.to_period("M"):
        notes["actual_start_warning"] = (
            f"Requested start was {REQUESTED_TEST_START.date()}, but the first valid "
            f"12-month BIL signal is {first_signal.date()} and first execution is "
            f"{first_execution.date()}. No proxy history was inserted."
        )
    return signals, notes


def single_asset_ledger(
    strategy_name: str,
    signals: pd.DataFrame,
    target_column: str,
    adj_open: pd.DataFrame,
    cost_bps_one_way: float,
) -> pd.DataFrame:
    rows = []
    previous_asset: Optional[str] = None

    for i in range(len(signals) - 1):
        current = signals.iloc[i]
        following = signals.iloc[i + 1]
        asset = str(current[target_column])
        start = pd.Timestamp(current["execution_date"])
        end = pd.Timestamp(following["execution_date"])

        start_price = float(adj_open.at[start, asset])
        end_price = float(adj_open.at[end, asset])
        gross_return = end_price / start_price - 1.0

        if previous_asset is None:
            gross_traded_notional = 1.0  # initial purchase
            switch = False
        elif previous_asset == asset:
            gross_traded_notional = 0.0
            switch = False
        else:
            gross_traded_notional = 2.0  # sell old + buy new
            switch = True

        cost = gross_traded_notional * cost_bps_one_way / 10_000.0
        net_return = (1.0 - cost) * (1.0 + gross_return) - 1.0

        rows.append(
            {
                "strategy": strategy_name,
                "cost_bps_one_way": cost_bps_one_way,
                "signal_date": pd.Timestamp(current["signal_date"]),
                "period_start": start,
                "period_end": end,
                "asset": asset,
                "start_adj_open": start_price,
                "end_adj_open": end_price,
                "gross_return": gross_return,
                "gross_traded_notional": gross_traded_notional,
                "transaction_cost": cost,
                "net_return": net_return,
                "switch": switch,
            }
        )
        previous_asset = asset

    return pd.DataFrame(rows)


def static_spy_ledger(
    signals: pd.DataFrame, adj_open: pd.DataFrame, cost_bps_one_way: float
) -> pd.DataFrame:
    synthetic = signals.copy()
    synthetic["SPY-BuyHold"] = "SPY"
    return single_asset_ledger(
        "SPY-BuyHold", synthetic, "SPY-BuyHold", adj_open, cost_bps_one_way
    )


def sixty_forty_ledger(
    signals: pd.DataFrame, adj_open: pd.DataFrame, cost_bps_one_way: float
) -> pd.DataFrame:
    target = pd.Series({"SPY": 0.60, "AGG": 0.40}, dtype=float)
    previous_end_weights: Optional[pd.Series] = None
    rows = []

    for i in range(len(signals) - 1):
        current = signals.iloc[i]
        following = signals.iloc[i + 1]
        start = pd.Timestamp(current["execution_date"])
        end = pd.Timestamp(following["execution_date"])
        asset_returns = adj_open.loc[end, target.index] / adj_open.loc[start, target.index] - 1.0

        if previous_end_weights is None:
            gross_traded_notional = float(target.abs().sum())
        else:
            gross_traded_notional = float((target - previous_end_weights).abs().sum())

        cost = gross_traded_notional * cost_bps_one_way / 10_000.0
        gross_return = float((target * asset_returns).sum())
        net_return = (1.0 - cost) * (1.0 + gross_return) - 1.0

        end_values = target * (1.0 + asset_returns)
        previous_end_weights = end_values / end_values.sum()

        rows.append(
            {
                "strategy": "60-40-SPY-AGG",
                "cost_bps_one_way": cost_bps_one_way,
                "signal_date": pd.Timestamp(current["signal_date"]),
                "period_start": start,
                "period_end": end,
                "asset": "SPY:60%;AGG:40%",
                "start_adj_open": np.nan,
                "end_adj_open": np.nan,
                "gross_return": gross_return,
                "gross_traded_notional": gross_traded_notional,
                "transaction_cost": cost,
                "net_return": net_return,
                "switch": gross_traded_notional > 1e-12,
            }
        )

    return pd.DataFrame(rows)


def build_all_ledgers(signals: pd.DataFrame, adj_open: pd.DataFrame) -> pd.DataFrame:
    ledgers = []
    for cost in (0.0, 5.0, 10.0):
        ledgers.extend(
            [
                single_asset_ledger("DM-Cash", signals, "DM-Cash", adj_open, cost),
                single_asset_ledger("DM-Bond", signals, "DM-Bond", adj_open, cost),
                single_asset_ledger(
                    "SPY-Absolute", signals, "SPY-Absolute", adj_open, cost
                ),
                single_asset_ledger(
                    "SPY-10M-SMA", signals, "SPY-10M-SMA", adj_open, cost
                ),
                static_spy_ledger(signals, adj_open, cost),
                sixty_forty_ledger(signals, adj_open, cost),
            ]
        )
    ledger = pd.concat(ledgers, ignore_index=True)
    ledger = ledger.sort_values(
        ["cost_bps_one_way", "strategy", "period_start"]
    ).reset_index(drop=True)
    return ledger


def filter_period(
    frame: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp
) -> pd.DataFrame:
    mask = (frame["period_start"] >= start) & (frame["period_start"] <= end)
    return frame.loc[mask].copy()


def calendar_returns(frame: pd.DataFrame, return_column: str = "net_return") -> pd.Series:
    if frame.empty:
        return pd.Series(dtype=float)
    series = frame.set_index("period_start")[return_column].sort_index()
    return series.groupby(series.index.year).apply(lambda x: float((1.0 + x).prod() - 1.0))


def max_drawdown(returns: pd.Series) -> float:
    if returns.empty:
        return float("nan")
    # Include the initial capital of 1.0 so a loss in the first observed month
    # is measured as a drawdown rather than treated as a new high-water mark.
    wealth_values = np.concatenate(([1.0], (1.0 + returns).cumprod().to_numpy()))
    wealth = pd.Series(wealth_values)
    drawdown = wealth / wealth.cummax() - 1.0
    return float(drawdown.min())


def compute_metrics(frame: pd.DataFrame, bil_frame: pd.DataFrame) -> PerformanceMetrics:
    if frame.empty:
        raise ValidationError("Cannot calculate metrics on an empty frame.")

    returns = frame.set_index("period_start")["net_return"].sort_index()
    bil_returns = bil_frame.set_index("period_start")["net_return"].reindex(returns.index)
    if bil_returns.isna().any():
        raise ValidationError("BIL risk-free return alignment failed.")

    n = len(returns)
    years = n / 12.0
    cumulative = float((1.0 + returns).prod() - 1.0)
    cagr = float((1.0 + cumulative) ** (1.0 / years) - 1.0)
    volatility = float(returns.std(ddof=1) * math.sqrt(12.0)) if n > 1 else float("nan")

    excess = returns - bil_returns
    excess_std = excess.std(ddof=1)
    sharpe = (
        float(excess.mean() / excess_std * math.sqrt(12.0))
        if n > 1 and excess_std > 0
        else float("nan")
    )
    downside = excess[excess < 0]
    downside_dev = float(np.sqrt(np.mean(np.square(downside)))) if len(downside) else 0.0
    sortino = (
        float(excess.mean() * 12.0 / (downside_dev * math.sqrt(12.0)))
        if downside_dev > 0
        else float("nan")
    )

    annual = calendar_returns(frame)
    if annual.empty:
        worst_year = None
        worst_return = float("nan")
    else:
        worst_year = int(annual.idxmin())
        worst_return = float(annual.min())

    gross_notional = float(frame["gross_traded_notional"].sum())
    switches = int(frame["switch"].sum())

    return PerformanceMetrics(
        observations=n,
        years=years,
        cumulative_return=cumulative,
        cagr=cagr,
        annualized_volatility=volatility,
        sharpe_vs_bil=sharpe,
        sortino_vs_bil=sortino,
        max_drawdown=max_drawdown(returns),
        worst_calendar_year=worst_year,
        worst_calendar_return=worst_return,
        annual_gross_traded_notional=gross_notional / years,
        switches_per_year=switches / years,
    )


def build_bil_risk_free_ledger(
    signals: pd.DataFrame, adj_open: pd.DataFrame
) -> pd.DataFrame:
    synthetic = signals.copy()
    synthetic["BIL-RiskFree"] = "BIL"
    # Zero costs: this series is used only as the return hurdle for Sharpe/Sortino.
    return single_asset_ledger(
        "BIL-RiskFree", synthetic, "BIL-RiskFree", adj_open, 0.0
    )


def summary_tables(ledger: pd.DataFrame, bil_risk_free: pd.DataFrame) -> pd.DataFrame:
    periods = {
        "Combined": (REQUESTED_TEST_START, HOLDOUT_END),
        "Development": (REQUESTED_TEST_START, DEVELOPMENT_END),
        "Holdout": (HOLDOUT_START, HOLDOUT_END),
        "2022": (pd.Timestamp("2022-01-01"), pd.Timestamp("2022-12-31")),
    }
    rows = []
    for period_name, (start, end) in periods.items():
        bil_period = filter_period(bil_risk_free, start, end)
        for (strategy, cost), group in ledger.groupby(
            ["strategy", "cost_bps_one_way"], sort=True
        ):
            period_frame = filter_period(group, start, end)
            if period_frame.empty:
                continue
            metrics = compute_metrics(period_frame, bil_period)
            row = {
                "period": period_name,
                "strategy": strategy,
                "cost_bps_one_way": cost,
                **asdict(metrics),
            }
            rows.append(row)
    return pd.DataFrame(rows)


def rolling_annualized_returns(
    ledger: pd.DataFrame, windows: Sequence[int] = (60, 120)
) -> pd.DataFrame:
    rows = []
    for (strategy, cost), group in ledger.groupby(
        ["strategy", "cost_bps_one_way"], sort=True
    ):
        series = group.set_index("period_start")["net_return"].sort_index()
        for window in windows:
            values = series.rolling(window).apply(
                lambda x: float(np.prod(1.0 + x) ** (12.0 / window) - 1.0),
                raw=True,
            )
            for date, value in values.dropna().items():
                rows.append(
                    {
                        "strategy": strategy,
                        "cost_bps_one_way": cost,
                        "window_months": window,
                        "window_end": date,
                        "annualized_return": float(value),
                    }
                )
    return pd.DataFrame(rows)


def rolling_summary(rolling: pd.DataFrame) -> pd.DataFrame:
    if rolling.empty:
        return pd.DataFrame()
    return (
        rolling.groupby(["strategy", "cost_bps_one_way", "window_months"])[
            "annualized_return"
        ]
        .agg(minimum="min", median="median", maximum="max")
        .reset_index()
    )


def start_month_sensitivity(
    ledger: pd.DataFrame, bil_risk_free: pd.DataFrame
) -> pd.DataFrame:
    rows = []
    for (strategy, cost), group in ledger.groupby(
        ["strategy", "cost_bps_one_way"], sort=True
    ):
        group = group.sort_values("period_start").reset_index(drop=True)
        for offset in range(12):
            subset = group.iloc[offset:].copy()
            subset = subset[subset["period_start"] <= HOLDOUT_END]
            if subset.empty:
                continue
            start = pd.Timestamp(subset["period_start"].min())
            bil_subset = bil_risk_free[
                (bil_risk_free["period_start"] >= start)
                & (bil_risk_free["period_start"] <= HOLDOUT_END)
            ]
            metrics = compute_metrics(subset, bil_subset)
            rows.append(
                {
                    "strategy": strategy,
                    "cost_bps_one_way": cost,
                    "offset_months": offset,
                    "actual_start": start,
                    "end": HOLDOUT_END,
                    "cagr": metrics.cagr,
                    "sharpe_vs_bil": metrics.sharpe_vs_bil,
                    "max_drawdown": metrics.max_drawdown,
                }
            )
    return pd.DataFrame(rows)


def moving_block_bootstrap_cagr_difference(
    strategy_returns: np.ndarray,
    benchmark_returns: np.ndarray,
    samples: int,
    block_length: int,
    seed: int,
) -> Tuple[float, float, float]:
    if len(strategy_returns) != len(benchmark_returns):
        raise ValidationError("Bootstrap series lengths do not match.")
    n = len(strategy_returns)
    if n < block_length:
        return float("nan"), float("nan"), float("nan")

    rng = np.random.default_rng(seed)
    starts = np.arange(0, n - block_length + 1)
    blocks_needed = math.ceil(n / block_length)
    diffs = np.empty(samples, dtype=float)

    for sample_idx in range(samples):
        selected_starts = rng.choice(starts, size=blocks_needed, replace=True)
        indices = np.concatenate(
            [np.arange(start, start + block_length) for start in selected_starts]
        )[:n]
        strat = strategy_returns[indices]
        bench = benchmark_returns[indices]
        strat_cagr = np.prod(1.0 + strat) ** (12.0 / n) - 1.0
        bench_cagr = np.prod(1.0 + bench) ** (12.0 / n) - 1.0
        diffs[sample_idx] = strat_cagr - bench_cagr

    lower, median, upper = np.quantile(diffs, [0.05, 0.50, 0.95])
    return float(lower), float(median), float(upper)


def bootstrap_table(ledger: pd.DataFrame, samples: int) -> pd.DataFrame:
    rows = []
    holdout = ledger[
        (ledger["period_start"] >= HOLDOUT_START)
        & (ledger["period_start"] <= HOLDOUT_END)
    ]
    for cost in (5.0, 10.0):
        bench = (
            holdout[
                (holdout["strategy"] == "60-40-SPY-AGG")
                & (holdout["cost_bps_one_way"] == cost)
            ]
            .set_index("period_start")["net_return"]
            .sort_index()
        )
        for strategy in ("DM-Cash", "DM-Bond"):
            strat = (
                holdout[
                    (holdout["strategy"] == strategy)
                    & (holdout["cost_bps_one_way"] == cost)
                ]
                .set_index("period_start")["net_return"]
                .sort_index()
            )
            aligned = pd.concat([strat.rename("strategy"), bench.rename("benchmark")], axis=1).dropna()
            lower, median, upper = moving_block_bootstrap_cagr_difference(
                aligned["strategy"].to_numpy(),
                aligned["benchmark"].to_numpy(),
                samples=samples,
                block_length=BOOTSTRAP_BLOCK_MONTHS,
                seed=BOOTSTRAP_SEED + int(cost) + (0 if strategy == "DM-Cash" else 1000),
            )
            rows.append(
                {
                    "strategy": strategy,
                    "cost_bps_one_way": cost,
                    "benchmark": "60-40-SPY-AGG",
                    "period": "Holdout",
                    "bootstrap_samples": samples,
                    "block_months": BOOTSTRAP_BLOCK_MONTHS,
                    "cagr_diff_ci_90_lower": lower,
                    "cagr_diff_median": median,
                    "cagr_diff_ci_90_upper": upper,
                }
            )
    return pd.DataFrame(rows)


def verdicts(summary: pd.DataFrame, bootstrap: pd.DataFrame) -> pd.DataFrame:
    """Apply the pre-registered holdout decision rules at the 10-bps stress cost."""
    holdout = summary[
        (summary["period"] == "Holdout")
        & (summary["cost_bps_one_way"] == 10.0)
    ].set_index("strategy")
    boot = bootstrap[bootstrap["cost_bps_one_way"] == 10.0].set_index("strategy")

    required = {"SPY-BuyHold", "60-40-SPY-AGG", "SPY-10M-SMA", "DM-Cash", "DM-Bond"}
    missing = required.difference(holdout.index)
    if missing:
        raise ValidationError(f"Missing holdout summaries needed for verdicts: {sorted(missing)}")

    rows = []
    spy = holdout.loc["SPY-BuyHold"]
    sixty_forty = holdout.loc["60-40-SPY-AGG"]
    trend = holdout.loc["SPY-10M-SMA"]

    for strategy in ("DM-Cash", "DM-Bond"):
        current = holdout.loc[strategy]
        lower_ci = float(boot.loc[strategy, "cagr_diff_ci_90_lower"])
        return_route = (
            current["cagr"] > 0
            and lower_ci > 0
            and current["sharpe_vs_bil"] >= sixty_forty["sharpe_vs_bil"]
        )

        # A negative drawdown closer to zero is better. Relative reduction is positive.
        drawdown_reduction = 1.0 - abs(current["max_drawdown"]) / abs(spy["max_drawdown"])
        not_worse_than_trend_on_both = not (
            current["cagr"] < trend["cagr"]
            and current["max_drawdown"] < trend["max_drawdown"]
        )
        risk_route = (
            drawdown_reduction >= 0.20
            and current["cagr"] >= sixty_forty["cagr"] - 0.01
            and not_worse_than_trend_on_both
        )

        if return_route or risk_route:
            verdict = "PASS"
            reason = "Return-enhancement route" if return_route else "Risk-control route"
        elif drawdown_reduction >= 0.20 and current["cagr"] > 0:
            verdict = "CONDITIONAL PASS"
            reason = "Material drawdown reduction, but return advantage is inconclusive"
        else:
            verdict = "FAIL"
            reason = "Neither the return-enhancement nor risk-control threshold was met"

        rows.append(
            {
                "strategy": strategy,
                "verdict_cost_bps_one_way": 10.0,
                "verdict": verdict,
                "reason": reason,
                "holdout_cagr": float(current["cagr"]),
                "holdout_sharpe_vs_bil": float(current["sharpe_vs_bil"]),
                "holdout_max_drawdown": float(current["max_drawdown"]),
                "drawdown_reduction_vs_spy": float(drawdown_reduction),
                "cagr_gap_vs_60_40": float(current["cagr"] - sixty_forty["cagr"]),
                "bootstrap_90_lower_cagr_diff_vs_60_40": lower_ci,
            }
        )
    return pd.DataFrame(rows)


def validation_checks(
    prices: Mapping[str, pd.DataFrame],
    adj_close: pd.DataFrame,
    adj_open: pd.DataFrame,
    signals: pd.DataFrame,
    ledger: pd.DataFrame,
    notes: Mapping[str, str],
    sources: Mapping[str, str],
) -> Dict[str, object]:
    checks: Dict[str, object] = {
        "download_start": DOWNLOAD_START,
        "download_end_exclusive": DOWNLOAD_END,
        "requested_test_start": str(REQUESTED_TEST_START.date()),
        "actual_first_signal": str(pd.Timestamp(signals["signal_date"].min()).date()),
        "actual_first_execution": str(pd.Timestamp(signals["execution_date"].min()).date()),
        "last_signal": str(pd.Timestamp(signals["signal_date"].max()).date()),
        "last_execution": str(pd.Timestamp(signals["execution_date"].max()).date()),
        "sources": dict(sources),
        "notes": dict(notes),
        "ticker_rows": {ticker: int(len(frame)) for ticker, frame in prices.items()},
        "duplicate_dates": {
            ticker: bool(frame.index.duplicated().any()) for ticker, frame in prices.items()
        },
        "nonpositive_adjusted_prices": {
            ticker: bool((frame[["adj_open", "adj_close"]] <= 0).any().any())
            for ticker, frame in prices.items()
        },
        "signal_dates_are_market_dates": bool(signals["signal_date"].isin(adj_close.index).all()),
        "execution_dates_are_market_dates": bool(signals["execution_date"].isin(adj_open.index).all()),
        "execution_after_signal": bool(
            (signals["execution_date"] > signals["signal_date"]).all()
        ),
        "ledger_missing_returns": int(ledger["net_return"].isna().sum()),
        "ledger_infinite_returns": int(
            np.isinf(ledger[["gross_return", "net_return"]].to_numpy()).sum()
        ),
        "holdout_months_available": int(
            signals["execution_date"].between(HOLDOUT_START, HOLDOUT_END).sum()
        ),
    }

    fatal_conditions = [
        any(checks["duplicate_dates"].values()),
        any(checks["nonpositive_adjusted_prices"].values()),
        not checks["signal_dates_are_market_dates"],
        not checks["execution_dates_are_market_dates"],
        not checks["execution_after_signal"],
        checks["ledger_missing_returns"] > 0,
        checks["ledger_infinite_returns"] > 0,
    ]
    checks["fatal_validation_failure"] = bool(any(fatal_conditions))
    return checks


def format_percent_columns(frame: pd.DataFrame) -> pd.DataFrame:
    # CSVs retain decimal values. This helper is used only for terminal output.
    frame = frame.copy()
    for column in [
        "cagr",
        "annualized_volatility",
        "max_drawdown",
        "worst_calendar_return",
    ]:
        if column in frame:
            frame[column] = frame[column].map(lambda x: f"{x:.2%}" if pd.notna(x) else "")
    for column in ["sharpe_vs_bil", "sortino_vs_bil"]:
        if column in frame:
            frame[column] = frame[column].map(lambda x: f"{x:.3f}" if pd.notna(x) else "")
    return frame


def main() -> int:
    args = parse_args()
    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        prices, sources = load_all_prices(args.data_dir, args.refresh)
        adj_close, adj_open, raw_long = build_price_panels(prices)
        signals, notes = generate_signals(adj_close, adj_open)
        ledger = build_all_ledgers(signals, adj_open)
        bil_risk_free = build_bil_risk_free_ledger(signals, adj_open)
        summary = summary_tables(ledger, bil_risk_free)
        rolling = rolling_annualized_returns(ledger)
        rolling_stats = rolling_summary(rolling)
        sensitivity = start_month_sensitivity(ledger, bil_risk_free)
        bootstrap = bootstrap_table(ledger, samples=args.bootstrap_samples)
        decisions = verdicts(summary, bootstrap)
        annual_rows = []
        for (strategy, cost), group in ledger.groupby(
            ["strategy", "cost_bps_one_way"], sort=True
        ):
            for year, value in calendar_returns(group).items():
                annual_rows.append(
                    {
                        "strategy": strategy,
                        "cost_bps_one_way": cost,
                        "year": int(year),
                        "calendar_return": float(value),
                    }
                )
        annual = pd.DataFrame(annual_rows)

        checks = validation_checks(
            prices, adj_close, adj_open, signals, ledger, notes, sources
        )
        if checks["fatal_validation_failure"]:
            raise ValidationError(
                "Fatal validation check failed. See validation_checks.json."
            )

        # Export raw and derived audit files.
        raw_export = raw_long.reset_index().sort_values(["ticker", "date"])
        raw_export.to_csv(output_dir / "raw_adjusted_prices.csv", index=False)
        signals.to_csv(output_dir / "monthly_signals.csv", index=False)
        ledger.to_csv(output_dir / "monthly_return_ledger.csv", index=False)
        bil_risk_free.to_csv(output_dir / "bil_risk_free_ledger.csv", index=False)
        summary.to_csv(output_dir / "performance_summary.csv", index=False)
        annual.to_csv(output_dir / "calendar_returns.csv", index=False)
        rolling.to_csv(output_dir / "rolling_returns.csv", index=False)
        rolling_stats.to_csv(output_dir / "rolling_return_summary.csv", index=False)
        sensitivity.to_csv(output_dir / "start_month_sensitivity.csv", index=False)
        bootstrap.to_csv(output_dir / "bootstrap_cagr_vs_60_40.csv", index=False)
        decisions.to_csv(output_dir / "verdicts.csv", index=False)

        with (output_dir / "validation_checks.json").open("w", encoding="utf-8") as file_obj:
            json.dump(checks, file_obj, indent=2, sort_keys=True)

        run_metadata = {
            "python_version": sys.version,
            "pandas_version": pd.__version__,
            "numpy_version": np.__version__,
            "yfinance_version": getattr(yf, "__version__", "unknown"),
            "bootstrap_seed": BOOTSTRAP_SEED,
            "bootstrap_samples": args.bootstrap_samples,
            "bootstrap_block_months": BOOTSTRAP_BLOCK_MONTHS,
            "rules": {
                "lookback_months": 12,
                "risk_assets": ["SPY", "EFA"],
                "absolute_hurdle": "BIL",
                "dm_cash_fallback": "BIL",
                "dm_bond_fallback": "AGG",
                "execution": "next common trading session adjusted open",
                "holding_return": "adjusted open to next adjusted open",
                "costs_bps_one_way": [0, 5, 10],
            },
        }
        with (output_dir / "run_metadata.json").open("w", encoding="utf-8") as file_obj:
            json.dump(run_metadata, file_obj, indent=2, sort_keys=True)

        # Add file hashes after all outputs exist.
        hashes = {
            path.name: sha256_file(path)
            for path in sorted(output_dir.iterdir())
            if path.is_file()
        }
        with (output_dir / "output_sha256.json").open("w", encoding="utf-8") as file_obj:
            json.dump(hashes, file_obj, indent=2, sort_keys=True)

        print(f"Results written to: {output_dir.resolve()}")
        if notes:
            for note in notes.values():
                warnings.warn(note)

        print("\nHoldout summary at 10 bps one-way costs:")
        display = summary[
            (summary["period"] == "Holdout")
            & (summary["cost_bps_one_way"] == 10.0)
        ][
            [
                "strategy",
                "cagr",
                "sharpe_vs_bil",
                "sortino_vs_bil",
                "max_drawdown",
                "worst_calendar_year",
                "worst_calendar_return",
                "switches_per_year",
            ]
        ]
        print(format_percent_columns(display).to_string(index=False))

        print("\nPre-registered verdicts:")
        print(decisions.to_string(index=False))
        return 0

    except (ValidationError, KeyError, ValueError, IndexError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
