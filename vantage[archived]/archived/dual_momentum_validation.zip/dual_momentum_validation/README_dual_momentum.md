# Dual-Momentum Validation

This package contains the corrected, auditable implementation of the pre-registered dual-momentum test.

## Files

- `dual_momentum_validation.py` — complete downloader, backtester, validation checks and exports.
- `requirements_dual_momentum.txt` — Python dependencies.

## Install

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

python -m pip install -r requirements_dual_momentum.txt
```

## Run

```bash
python dual_momentum_validation.py --output-dir dual_momentum_results
```

To cache the downloaded input data:

```bash
python dual_momentum_validation.py \
  --data-dir price_csvs \
  --output-dir dual_momentum_results
```

On Windows PowerShell, place the command on one line or use the PowerShell backtick for continuation.

## Important start-date correction

BIL began trading in May 2007. A full twelve-month BIL return cannot be computed in January 2008 without inserting a proxy. The script does not insert one. It reports the first valid signal and execution date in `validation_checks.json`.

## Main outputs

- `monthly_signals.csv`
- `monthly_return_ledger.csv`
- `performance_summary.csv`
- `calendar_returns.csv`
- `rolling_returns.csv`
- `start_month_sensitivity.csv`
- `bootstrap_cagr_vs_60_40.csv`
- `verdicts.csv`
- `validation_checks.json`
- `run_metadata.json`
- `output_sha256.json`

Upload the entire output directory, preferably as a ZIP file. The most important files are `monthly_signals.csv`, `monthly_return_ledger.csv`, `performance_summary.csv`, `verdicts.csv`, and `validation_checks.json`.
